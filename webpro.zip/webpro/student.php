﻿<!DOCTYPE html>
<?php  error_reporting(0); ?>
<html lang="en">


<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Mouldifi - A fully responsive, HTML5 based admin theme">
<meta name="keywords" content="Responsive, HTML5, admin theme, business, professional, Mouldifi, web design, CSS3">
<title>افغان مودل |شاگردان</title>
<!-- Site favicon -->
<link rel='shortcut icon' type='image/x-icon' href='images/favicon.ico' />
<!-- /site favicon -->

<!-- Entypo font stylesheet -->
<link href="css/entypo.css" rel="stylesheet">
<!-- /entypo font stylesheet -->

<!-- Font awesome stylesheet -->
<link href="css/font-awesome.min.css" rel="stylesheet">
<!-- /font awesome stylesheet -->

<!-- CSS3 Animate It Plugin Stylesheet -->
<link href="css/plugins/css3-animate-it-plugin/animations.css" rel="stylesheet">
<!-- /css3 animate it plugin stylesheet -->
<!-- Entypo font stylesheet -->
<link href="fonts/myfont.css" rel="stylesheet">
<link href="fonts/custom.css" rel="stylesheet">
<!-- Bootstrap stylesheet min version -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!-- /bootstrap stylesheet min version -->

<!-- Mouldifi core stylesheet -->
<link href="css/mouldifi-core.css" rel="stylesheet">
<!-- /mouldifi core stylesheet -->

<!-- Bootstrap RTL stylesheet min version -->
<link href="css/bootstrap-rtl.min.css" rel="stylesheet">
<!-- /bootstrap rtl stylesheet min version -->

<!-- Mouldifi RTL core stylesheet -->
<link href="css/mouldifi-rtl-core.css" rel="stylesheet">
<!-- /mouldifi rtl core stylesheet -->

<link href="css/mouldifi-forms.css" rel="stylesheet">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
<![endif]-->
</head>
<body>
<?php
$userid=$_GET['id'];
?>
<!-- Page container -->
<div class="page-container">

  <!-- Page Sidebar -->
  <div class="page-sidebar">
  
  		<!-- Site header  -->
		<header class="site-header">
		  <div class="site-logo"><a href="index-2.html"><img src="images/persion_logo.png" alt="Mouldifi" title="Mouldifi"></a></div>
		  <div class="sidebar-collapse hidden-xs"><a class="sidebar-collapse-icon" href="#"><i class="icon-menu"></i></a></div>
		  <div class="sidebar-mobile-menu visible-xs"><a data-target="#side-nav" data-toggle="collapse" class="mobile-menu-icon" href="#"><i class="icon-menu"></i></a></div>
		</header>
		<!-- /site header -->
		
		<!-- Main navigation -->
		<ul id="side-nav" class="main-menu navbar-collapse collapse" >
			<li class="has-sub"><a href="index-2.html" id='navigation_li'><i class="icon-user"></i><span class="title">حساب من</span></a>
				<ul class="nav collapse">
					<li><a href="student_edite.php?userid=<?php  echo $userid;?>" class="navigation_sub_li"><span class="title">ویرایش حساب</span></a></li>
					
					<li><a href="student_edite_password.php?id=<?php  echo $userid;?>" class="navigation_sub_li"  ><span class="title">تغیر رمز عبور</span></a></li>
				</ul>
			</li>

			<li class="has-sub"><a href="collapsed-sidebar.html" id='navigation_li'><i class="icon-docs"></i><span class="title">دوره های آموزشی</span></a>
				
						<?php
 				include_once"data/curd.php";
 				$obj=new curd();
 				$re=$obj->list_cours();
 				foreach ($re as $value) {
 					$shortname=$value['shortname'];
 					$id=$value['id'];
 					echo "
 					<ul class='nav collapse'>
 					<li><a href='#post$id' class='navigation_sub_li'><span class='title'>$shortname</span></a></li>
 					</ul>

 					";
 					
 				}


			?>
					
					
				
			</li>
			<li class="has-subن"><a href="user_list.php?userid=<?php echo $userid; ?>"><i class="icon-chat"></i><span class="title" id='navigation_li'>پیام </span></a>
				
			</li>
		
			
		
		</ul>
		<!-- /main navigation -->		
  </div>
  <!-- /page sidebar -->
  
  <!-- Main container -->
  <div class="main-container">
  
	<!-- Main header -->
    <div class="main-header row">
      <div class="col-sm-6 col-xs-7">
	  
		<!-- User info -->
		<?php
        include_once"data/curd.php";
        $obj=new curd();
        $info=$obj->user_info($userid);
        $uname="";

        foreach ($info as $value) {
        	$uname=$value['name'];
        }


		?>
        <ul class="user-info pull-left">          
          <li class="profile-info dropdown"><a data-toggle="dropdown" class="dropdown-toggle" href="#" aria-expanded="false" style="font-family: 'a'; font-size:22px;"> <img width="44" class="img-circle avatar" alt="" src="userphoto/<?php     echo $userid;  ?>.jpg"><?php  echo $uname; ?> <span class="caret"></span></a>
		  
			<!-- User action menu -->
            <ul class="dropdown-menu">
              
              <li><a href="student_edite.php?userid=<?php  echo $userid;?>"><i class="icon-user"></i>حساب من</a></li>
              <li><a href="user_list.php?userid=<?php  echo $userid; ?>"><i class="icon-mail"></i>پیام ها</a></li>
              
			  <li class="divider"></li>
			  <li><a href="student_edite_password.php?id=<?php  echo $userid;?>"><i class="icon-cog"></i>تنظیمات حساب</a></li>
			  <li><a href="index.php"><i class="icon-logout"></i>خروج</a></li>
            </ul>
			<!-- /user action menu -->
			
          </li>
        </ul>
		<!-- /user info -->
		
      </div>
	  
      <div class="col-sm-6 col-xs-5">
	  	<div class="pull-right">
			<!-- User alerts -->
			<ul class="user-info pull-left">
			
			  <!-- Notifications -->
			
			  <!-- /notifications -->
			  
			  <!-- Messages -->
			  <?php  
             include_once"data/curd.php";
			 $ob=new curd();
			 $data=$ob->show_user_for_messege($userid);
			 $count=0;
			if (!empty($data)) {
				foreach ($data as  $value) {
			 	$count++;
			 }
			
		}
			 




			  ?>
			  <li class="notifications dropdown">
				<a data-close-others="true" data-hover="dropdown" data-toggle="dropdown" class="dropdown-toggle" href="#"><i class="icon-mail"></i><span class="badge badge-secondary"><?php echo $count; ?></span></a>
				<ul class="dropdown-menu pull-right">
					<li class="first">
						<div class="dropdown-content-header" id='messege_box_username'><i class="fa fa-pencil-square-o pull-right"></i> پیام ها</div>
					</li>
					<li>
						<ul class="media-list">
							<?php
							include_once"data/curd.php";
							$ob=new curd();
							$data=$ob->show_user_for_messege($userid);
							if (!empty($data)) {
								foreach ($data as  $value) {
								$senderid=$value['senderrid'];
								

								$date="2018/Jun/Fri";
								$d=$ob->show_user_name($senderid);
								$name="";
								$lastname="";
								foreach ($d as $value) {
									$name=$value['name'];
									$lastname=$value['lastname'];
								}
								
								$d2=$ob->get_messege($senderid,$userid);
								$messege="";
								foreach ($d2 as $value) {
									$messege=$value['messege'];
									
								}
								
								if ($senderid!=$userid) {
									echo "

							<li class='media'>
								<div class='media-left'><img  class='img-circle img-sm' src='userphoto/$senderid.jpg'></div>
								<div class='media-body'>
									<a class='media-heading' href='messege.php ?id=$userid & name=$name & pid=$senderid''>
										<span class='text-semibold' id='messege_box_username'>$name $lastname</span>
										<span class='media-annotation pull-right'>$date</span>
									</a>
									<span class='text-muted' id='messege_box_messege'>$messege</span>
								</div>
							</li>

								";	
									
								}								

							}
							}
							


							?>



							
							
						
						</ul>
					</li>
					<li class="external-last"> <a class="danger" href="#">All Messages</a> </li>
				</ul>
			  </li>
			  <!-- /messages -->
			  
			</ul>
			<!-- /user alerts -->
			
		</div>
      </div>
    </div>
	<!-- /main header -->
	
	<!-- Main content -->
	<div class="main-content">
		
		<div class="row">
			<div class="col-lg-12">
				<div class="row">
			<div class="col-md-12">
            <h2 style="" id="course_title">دورهای آموزشی موجود</h2>

<?php
include_once"data/curd.php";
$obj=new curd();
$data=$obj->show_course();
foreach ($data as $value) {
	$id=$value['id'];
	$fullname=$value['fullname'];
	$shortname=$value['shortname'];
	$file=$value['file'];
	$data=$value['date'];
	$userid=$value['userid'];
    $d=$obj->user_info($userid);
    $name="";
    $lastname="";
    $email="";
    foreach ($d as $value2) {
    	$name=$value2['name'];
    	$lastname=$value2['lastname'];
    	$email=$value2['email'];

    }
$ssid=$_GET['id'];
	echo "
	<div class='cards-container box-view'>
				
					<div class='animatedParent animateOnce z-index-50'>
						<!-- Card -->
						<div class='card animated fadeInUp' id='post$id'>
						
							<!-- Card header -->
							<div class='card-header'>
							
								<!-- Card photo -->
								<div class='card-photo'>
									<img class='img-circle avatar' src='userphoto/$userid.jpg' alt='$lastname' title='John Henderson'>
								</div>
								<!-- /card photo -->
								
								<!-- Card short description -->
								<div class='card-short-description' >
									<h5><span class='user-name'><a href='user_info.php?userid=$userid' id='post_header'>$name  $lastname</a></span></h5>
									<p><a href='mailto:$email' id='post_header'>$email</a></p>
								</div>
								
								<!-- /card short description -->
								
							</div>
							<!-- /card header -->
							
							<!-- Card content -->
							<div class='card-content'>
								<div >
									<h3 id='post_title'>$shortname</h3>
								</div>
								<p id='post_desc'>$fullname</p>
								<ul class='list-inline list-action'>
									<li><a href='course_info.php?cid=$id & username=$name' id='post_desc'>توضیحات بیشتر</a></li>
									
									<li><a href='messege.php?id=$ssid & name=$name & pid=$userid' id='post_desc'>ارسال پیام</a></li>
								</ul>
							</div>
							<!-- /card content -->
							
						</div>
						<!-- /card -->
					</div>
					
					
				</div>

	";



}



?>

<!-- Card list view -->
			


			
				<!-- /card list view -->
				
			</div>
		</div>	
			</div>
		</div>
		<br><br><br><br><br>
		
		<!-- Footer -->
		<footer class="animatedParent animateOnce z-index-10"> 
			<div class="footer-main animated fadeInUp slow" id="member_request" style="text-align: center">&copy; تمامی حقوف این سایت متعلق به  <strong>افغان مودل </strong> می باشد  </div>
		</footer>	
		<!-- /footer -->

		
		
	  </div>
	  <!-- /main content -->
	  
  </div>
  <!-- /main container -->
  
</div>
<!-- /page container -->

<!--Load JQuery-->
<script src="js/jquery.min.js"></script>
<!-- Load CSS3 Animate It Plugin JS -->
<script src="js/plugins/css3-animate-it-plugin/css3-animate-it.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/plugins/metismenu/jquery.metisMenu.js"></script>
<script src="js/functions.js"></script>
</body>

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/blank-page.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:41:18 GMT -->
</html>
