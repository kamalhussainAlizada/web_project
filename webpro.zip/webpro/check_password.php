


<?php
$password=$_GET['password'];
$length=strlen($password);
$weekPattern = "/^[A-Za-z]{1,}$/";
$middelPattern = "/^(\w)*(\d){1,}(\D)*[A-Za-z]{1,}(\w)*$/";
$strongPattern = "/^(\w)*(\W){1,}(\d){1,}(\w){1,}(\w)*$/"; 


if (preg_match($strongPattern,$password) && $length>=8) {
	echo "
<div style='color:rgb(92,228,109); font-size:20px;border:1px dashed rgb(92,228,109)'>توجه ! رمز عبور حساب کاربری شما عالی می باشد</div>
	";
}
else
if (preg_match($middelPattern,$password) && $length>=5 ){
	echo "
<div style='color:rgb(101,199,220); font-size:20px;border:1px dashed rgb(101,199,220)'>توجه ! رمز عبور حساب کاربری شما خوب می باشد</div>
	";
}
else
 {
		
	
echo "
<div style='color:rgb(251,49,84); font-size:20px; border:1px dashed rgb(251,49,84)'>توجه ! رمز عبور حساب کاربری شما ضعیف می باشد</div>
";
}











?>


