<?php
$admin=0;;
$Teacher=0;;
$Student=0;
function d(){
include_once"data/curd.php";
$ob=new curd();
$data=$ob->show_user_precentage();


$admin=$data[0];
$Teacher=$data[1];
$Student=$data[2];
}
function bar_chart($question, $answers,$total2) {

	$colors = array(0xFF6600, 0x009900, 0x3333CC,
 0xFF0033, 0xFFFF00, 0x66FFFF, 0x9900CC);
 $total = array_sum($answers['votes' ]);
 // define spacing values and other magic numbers
 $padding = 80;
 $line_width = 20;
 $scale = $line_width * 35;
 $bar_height = 20;
 $x = $y = $padding;

 // allocate a large palette for drawing, since you don't know
 // the image length ahead of time
 $image = ImageCreateTrueColor(500, 400);
 ImageFilledRectangle($image, 0, 0,500, 400, 0xE0E0E0);
 $black = 0x000000;
 // print the question

$size = 18;
$angle = 0;
$x = 20;
$y = 35;
$text_color = 0x000000; // black
$text = 'Graph Of Users Accourding User Type' ;
$fontpath = __DIR__ . '/fonts/Nazanin Normal_ Emperor.Ir.ttf' ;
ImageFTText($image, $size, $angle, $x, $y, $text_color, $fontpath,
 $text);



 $y += $padding;
 // print the answers
 for ($i = 0; $i < count($answers['answer' ]); $i++) {
 // format percentage
 $percent = sprintf('%1.1f' , 100*$answers['votes' ][$i] /$total);
 $bar = sprintf('%d' , $scale*$answers['votes' ][$i] /$total);
 // grab color
 $c = $i % count($colors); // handle cases with more bars than colors
 $text_color = $colors[$c];
 // draw bar and percentage numbers
 ImageFilledRectangle($image, $x, $y, $x + $bar,
 $y + $bar_height, $text_color);
 ImageFTText($image,14, $angle, $x + $bar + $padding, $y+15, $text_color, $fontpath,
 " $percent% ");

 $y += 50;
 // print answer
 $wrapped = explode(" \n" , wordwrap($answers['answer' ][$i], $line_width));
 foreach ($wrapped as $line) {
 ImageFTText($image,14, $angle, $x, $y, $text_color, $fontpath,
 $line);
 $y += 12;
 }
 $y += 7;
 }
  ImageFTText($image,18, $angle, 10, 390, $black, $fontpath,
 " Usert Count : $total2");
 ImageFTText($image,18, $angle, 392, 390, $black, $fontpath,
 " AfMoodle ");
 // crop image by copying it
 $chart = ImageCreateTrueColor(500, 400);
 ImageCopy($chart, $image, 0, 0, 0, 0, 500, 400);
 // PHP 5.5+ supports
 // $chart = ImageCrop($image, array('x' => 0, 'y' => 0,
 // 'width' => 150, 'height' => $y));
 // deliver image
 header ('Content-type: image/png' );
 ImagePNG($chart);
 // clean up
 ImageDestroy($image);
 ImageDestroy($chart);

}
$admin=$_GET['admin'];
$teacher=$_GET['teacher'];
$student=$_GET['student'];
$total=$_GET['total'];

// Act II. Scene II.
$question = 'What a piece of work is man?' ;
$answers['answer' ][] = 'Admin' ;
$answers['votes' ][]  = $admin;
$answers['answer' ][] = 'Teacher' ;
$answers['votes' ][]  = $teacher;
$answers['answer' ][] = 'Student' ;
$answers['votes' ][]  = $student;

bar_chart($question, $answers,$total);


?>
