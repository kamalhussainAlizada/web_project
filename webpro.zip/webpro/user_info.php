<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:41:18 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="افغات مودل">
<meta name="keywords" content="مودل">
<title>Afghan Moodel | Login</title>
<!-- Site favicon -->
<link rel='shortcut icon' type='image/x-icon' href='images/icon2.png' />
<!-- /site favicon -->

<!-- Entypo font stylesheet -->
<link href="css/entypo.css" rel="stylesheet">
<!-- /entypo font stylesheet -->

<!-- Entypo font stylesheet -->
<link href="fonts/myfont.css" rel="stylesheet">
<!-- /entypo font stylesheet -->

<!-- Font awesome stylesheet -->
<link href="css/font-awesome.min.css" rel="stylesheet">
<!-- /font awesome stylesheet -->

<!-- CSS3 Animate It Plugin Stylesheet -->
<link href="css/plugins/css3-animate-it-plugin/animations.css" rel="stylesheet">
<!-- /css3 animate it plugin stylesheet -->

<!-- Bootstrap stylesheet min version -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!-- /bootstrap stylesheet min version -->

<!-- Mouldifi core stylesheet -->
<link href="css/mouldifi-core.css" rel="stylesheet">
<!-- /mouldifi core stylesheet -->

<link href="css/mouldifi-forms.css" rel="stylesheet">

<!-- Bootstrap RTL stylesheet min version -->
<link href="css/bootstrap-rtl.min.css" rel="stylesheet">
<!-- /bootstrap rtl stylesheet min version -->

<!-- Mouldifi RTL core stylesheet -->
<link href="css/mouldifi-rtl-core.css" rel="stylesheet">
<!-- /mouldifi rtl core stylesheet -->

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
<![endif]-->


</head>

<body class="login-page" id="body">
	<?php
$userid=$_GET['userid'];
include_once"data/curd.php";
$obj=new curd();
$d=$obj->user_info($userid);
    $name="";
    $lastname="";
    $email="";
    $status="";
    $type="";
    foreach ($d as $value2) {
    	$name=$value2['name'];
    	$lastname=$value2['lastname'];
    	$email=$value2['email'];
    	$state=$value2['status'];
    	if ($state==0) {
    		$status="تائید ناشده";
    	}else
    	if($state==1){
         $status="فعال";
    	}
    	else{
    		$status="غیر فعال";
    	}
    	$type=$value2['type'];


    }

	?>
	<div class="login-pag-inner">
		<div class="animatedParent animateOnce z-index-50">
			<div class="login-container animated growIn slower">
				
				<div class="login-content">
						<div class="card profile-intro text-center  animated fadeInUp">
	                        
								 <!-- Card header -->
								 <div class="card-header">
									  <div class="card-image card-image-full">
										   <img src="images/blog-6.jpg" alt="Blog">
										   <img class="avatar-130 img-circle" src="userphoto/<?php  echo $userid; ?>.jpg" alt="<?php echo $lastname; ?>">
									  </div>
								 </div>
								 <!-- /card header -->
	
								 <!-- Card content -->
								 <div class="card-content" style="font-size:20px; ">
									  <h3 style="font-family: 'a'; font-weight:bold; font-size: 22px;"><?php  echo $name." ".$lastname;  ?></h3>
									  <p style="">ایمیل آدرس : <?php  echo $email; ?></p>
									  <p>نوعیت حساب کاربری : <?php  echo $type; ?></p>
									  <p>حالت حساب : <?php  echo $status; ?></p>
								 </div>
								 <!-- /card-content  -->
	
								 <!-- Card Footer  -->
								 <div class="card-footer">
									  <ul class="social-link">
									  	<li>
										   <a class="icon" href="#/" target="_blank">
												<i class="fa fa-facebook"></i>
										   </a>
										</li>
										<li>
										   <a class="icon" href="#/" target="_blank">
												<i class="fa fa-twitter"></i>
										   </a>
										</li>
										<li>
										   <a class="icon" href="#/" target="_blank">
												<i class="fa fa-linkedin"></i>
										   </a>
										</li>
									  </ul>
								 </div>
								 <!-- .card footer  -->
							</div>
				</div>
			</div>
		</div>
	</div>
<!--Load JQuery-->
<script src="js/jquery.min.js"></script>
<!-- Load CSS3 Animate It Plugin JS -->
<script src="js/plugins/css3-animate-it-plugin/css3-animate-it.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:41:18 GMT -->
</html>
