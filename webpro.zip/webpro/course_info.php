<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:41:18 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="افغات مودل">
<meta name="keywords" content="مودل">
<title>افغان مودل | درباره کورس</title>
<!-- Site favicon -->
<link rel='shortcut icon' type='image/x-icon' href='images/icon2.png' />
<!-- /site favicon -->

<!-- Entypo font stylesheet -->
<link href="css/entypo.css" rel="stylesheet">
<!-- /entypo font stylesheet -->

<!-- Entypo font stylesheet -->
<link href="fonts/myfont.css" rel="stylesheet">
<!-- /entypo font stylesheet -->

<!-- Font awesome stylesheet -->
<link href="css/font-awesome.min.css" rel="stylesheet">
<!-- /font awesome stylesheet -->

<!-- CSS3 Animate It Plugin Stylesheet -->
<link href="css/plugins/css3-animate-it-plugin/animations.css" rel="stylesheet">
<!-- /css3 animate it plugin stylesheet -->

<!-- Bootstrap stylesheet min version -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!-- /bootstrap stylesheet min version -->

<!-- Mouldifi core stylesheet -->
<link href="css/mouldifi-core.css" rel="stylesheet">
<!-- /mouldifi core stylesheet -->

<link href="css/mouldifi-forms.css" rel="stylesheet">

<!-- Bootstrap RTL stylesheet min version -->
<link href="css/bootstrap-rtl.min.css" rel="stylesheet">
<!-- /bootstrap rtl stylesheet min version -->

<!-- Mouldifi RTL core stylesheet -->
<link href="css/mouldifi-rtl-core.css" rel="stylesheet">
<!-- /mouldifi rtl core stylesheet -->

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
<![endif]-->


</head>

<body class="login-page" id="body">
	<?php
$courseid=$_GET['cid'];
$username=$_GET['username'];
include_once"data/curd.php";
$obj=new curd();
$d=$obj->course_info($courseid);
    $fullname="";
    $shortname="";
    $date="";
    $file="";
    
    foreach ($d as $value2) {
    	$fullname=$value2['fullname'];
    	$shortname=$value2['shortname'];
    	$date=$value2['date'];
    	$file=$value2['file'];
    	


    }

	?>
	<div class="login-pag-inner">
		<div class="animatedParent animateOnce z-index-50">
			<div class="login-container animated growIn slower">
				
				<div class="login-content">
						<div class="card profile-intro text-center  animated fadeInUp">
	                        
								 <!-- Card header -->
								 <div class="card-header">
									  <div class="card-image card-image-full">
										   <img src="images/blog-6.jpg" alt="Blog">
										   <img class="avatar-130 img-circle" src="images/pdf.PNG" alt="">
									  </div>
								 </div>
								 <!-- /card header -->
	
								 <!-- Card content -->
								 <div class="card-content" style="font-size:20px; ">
									  
									<p>نام کورس:<?php echo $shortname; ?></p>
									<p>تاریخ نشر:<?php echo $date; ?></p>
									<p>استاد برگذار کننده: <?php echo $username; ?></p>
									<p>توضیحات: <?php echo $fullname; ?></p>
									<p><a href="course_file/<?php echo $file; ?>">خواندن</a></p>
									<p><a href="course_file/<?php echo $file; ?>" download>دانلود فایل</a></p>
									<p><a href="business/download_zip.php?filename=<?php echo $file;  ?> & fileid=<?php echo $courseid;  ?>">دانلود فایل به صورت فشرده</a></p>

								 </div>
								 <!-- /card-content  -->
	
								 <!-- Card Footer  -->
								
								 <!-- .card footer  -->
							</div>
				</div>
			</div>
		</div>
	</div>
<!--Load JQuery-->
<script src="js/jquery.min.js"></script>
<!-- Load CSS3 Animate It Plugin JS -->
<script src="js/plugins/css3-animate-it-plugin/css3-animate-it.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:41:18 GMT -->
</html>
