﻿<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:41:18 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Mouldifi - A fully responsive, HTML5 based admin theme">
<meta name="keywords" content="Responsive, HTML5, admin theme, business, professional, Mouldifi, web design, CSS3">
<title>افغان مودل | پیام</title>
<!-- Site favicon -->
<link rel='shortcut icon' type='image/x-icon' href='images/icon2.png' />
<!-- /site favicon -->




<!-- Entypo font stylesheet -->
<link href="fonts/myfont.css" rel="stylesheet">
<!-- /entypo font stylesheet -->

<!-- CSS3 Animate It Plugin Stylesheet -->
<!--
<link href="css/plugins/css3-animate-it-plugin/animations.css" rel="stylesheet">
-->
<!-- /css3 animate it plugin stylesheet -->

<!-- Bootstrap stylesheet min version -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!-- /bootstrap stylesheet min version -->

<!-- Mouldifi core stylesheet -->
<link href="css/mouldifi-core.css" rel="stylesheet">
<!-- /mouldifi core stylesheet -->

<link href="css/mouldifi-forms.css" rel="stylesheet">

<!-- Bootstrap RTL stylesheet min version -->
<link href="css/bootstrap-rtl.min.css" rel="stylesheet">
<!-- /bootstrap rtl stylesheet min version -->

<!-- Mouldifi RTL core stylesheet -->
<link href="css/mouldifi-rtl-core.css" rel="stylesheet">
<!-- /mouldifi rtl core stylesheet -->


<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />

<script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
<!--
messege file

-->

<style>


.container {
    border: 2px solid #dedede;
    background-color: #f1f1f1;
    border-radius: 5px;
    padding: 10px;
    margin: 10px 0;
    width: 100%;
}

.darker {
    border-color: #ccc;
    background-color: #ddd;
}

.container::after {
    content: "";
    clear: both;
    display: table;
}

.container img {
    float: left;
    max-width: 60px;
    width: 100%;
    margin-right: 20px;
    border-radius: 50%;
}

.container img.right {
    float: right;
    margin-left: 20px;
    margin-right:0;
}

.time-right {
    float: right;
    color: #aaa;
}

.time-left {
    float: left;
    color: #999;
}


<style>
    .pb-chat-panel {
        border: none;
        margin-bottom: -5px;
    }

    .pb-chat-panel-heading {
        margin-top: -5px;
    }

    .pb-chat-top-icons {
        margin-top: 4px;
    }

    #support_label {
        color: #999;
    }

    .pb-chat-labels {
        font-size: 15px;
    }

    .pb-chat-labels-right {
        margin-bottom: 0;
        margin-right: 5px;
    }


    .pb-chat-labels-left {
        margin-left: 5px;
    }

    .pb-chat-labels-primary {
        margin-right: 5px;
    }

    .pb-chat-fa-user {
        border: 1px solid blue;
        padding: 5px;
        border-radius: 50%;
    }

    .pb-chat-textarea {
        resize: none;
    }

    .pb-chat-dropdown {
        width: 300px;
    }

    .pb-chat-btn-circle {
        border-radius: 35px;
    }

    .pb-btn-circle-div {
        padding-left: 0px;
        margin-top: 12px;
    }
</style>

</style>


</head>
<body class="login-page" id="body">
<?php
error_reporting(0);
$userid=$_GET['id'];
$name=$_GET['name'];
$pid=$_GET['pid'];
?>

	<div class="login-pag-inner">
		<div class="animatedParent animateOnce z-index-50">
			<div class="login-container animated growIn slower">
				
				<div class="login-content" style="height :600px; overflow: scroll;">
					
					<div class="card-photo">
					    <center>
					    	<span id='title' style="font-weight: bold;font-size: 20px;"><?php  echo $name; ?></span>
					    </center>
					 </div>
					
<?php 
include_once"data/curd.php";
$obj=new curd();
$result=$obj->read_messege($userid,$pid);
$uid=$_GET['id'];
$senid=0;
if (!empty($result)) {
	

foreach ($result as $value) {
 $messege=$value['messege'];
 $date=$value['date'];
 $senderid=$value['senderrid'];
 $reciever=$value['reciever'];
 $a=$uid+0;
 
 if ($senderid!=$a) {
  $senid=$senderid;
 
   echo "
<div class='container'>
  <img src='userphoto/$a.jpg' alt='$name' style='width:100%;'>
  <p style='font-size:20px;'>$messege</p>
  <span class='time-right'>$date</span>
</div>


   ";
 }
 else{
  echo "

<div class='container darker'>
  <img src='userphoto/$reciever.jpg' alt='Avatar' class='right' style='width:100%;'>
  <p style='font-size: 20px;'>$messege</p>
  <span class='time-left'>$date</span>
</div>

  ";

 }



}}
 ?>





  <div class="panel-footer">
		        <div class="row">
		               <div class="col-xs-10">
                    
                    <form action="business/getmessege.php?sid=<?php echo  $userid; ?>&name=<?php echo $name.'-'; ?> & pid=<?php echo $pid; ?>" method="post">
		                    <textarea placeholder="تایپ کنید..." cols="18" style="font-size: 19px" name="messege" required=" required" ></textarea>
		                        </div>
		                         <div class="col-xs-2 pb-btn-circle-div">
		                    <button class="btn btn-primary btn-circle pb-chat-btn-circle"><span class="fa fa-chevron-right"></span></button>
                          </form>
		                                            </div>
		                                        </div>
		                                    </div>


				</div>
			</div>
		</div>
	</div>
<!--Load JQuery-->
<script src="js/jquery.min.js"></script>
<!-- Load CSS3 Animate It Plugin JS -->
<script src="js/plugins/css3-animate-it-plugin/css3-animate-it.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:41:18 GMT -->
</html>
