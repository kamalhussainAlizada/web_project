﻿<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/detailed-view-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:43:21 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Mouldifi - A fully responsive, HTML5 based admin theme">
<meta name="keywords" content="Responsive, HTML5, admin theme, business, professional, Mouldifi, web design, CSS3">
<title>Mouldifi | Detailed View</title>
<!-- Site favicon -->
<link rel='shortcut icon' type='image/x-icon' href='images/favicon.ico' />
<!-- /site favicon -->

<!-- Entypo font stylesheet -->
<link href="css/entypo.css" rel="stylesheet">
<link href="fonts/custom.css" rel="stylesheet">
<!-- /entypo font stylesheet -->

<!-- Font awesome stylesheet -->
<link href="css/font-awesome.min.css" rel="stylesheet">
<!-- /font awesome stylesheet -->

<!-- CSS3 Animate It Plugin Stylesheet -->
<link href="css/plugins/css3-animate-it-plugin/animations.css" rel="stylesheet">
<!-- /css3 animate it plugin stylesheet -->

<!-- Bootstrap stylesheet min version -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!-- /bootstrap stylesheet min version -->

<!-- Mouldifi core stylesheet -->
<link href="css/mouldifi-core.css" rel="stylesheet">
<!-- /mouldifi core stylesheet -->

<link href="css/plugins/select2/select2.css" rel="stylesheet">
<link href="css/mouldifi-forms.css" rel="stylesheet">

<!-- Bootstrap RTL stylesheet min version -->
<link href="css/bootstrap-rtl.min.css" rel="stylesheet">
<!-- /bootstrap rtl stylesheet min version -->

<!-- Mouldifi RTL core stylesheet -->
<link href="css/mouldifi-rtl-core.css" rel="stylesheet">
<!-- /mouldifi rtl core stylesheet -->


<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
<![endif]-->
</head>
<body>
<?php  error_reporting(0) ?>
<!-- Page container -->
<div class="page-container">

  <!-- Page Sidebar -->
 
  <!-- /page sidebar -->
  
  <!-- Main container -->
  <div class="main-container">
  
	<!-- Main header -->
    <div class="main-header row gray-bg">
      <div class="col-sm-6 col-xs-7">
	  
		<!-- User info -->
      
		<!-- /user info -->
		
      </div>
	  
      
    </div>
	<!-- /main header -->
	
	<!-- Secondary header -->
	
	<!-- /secondary header -->
	

	<!-- /filter wrapper -->
	
	<!-- Main content -->
    <div class="main-content">
	
		<!-- List header -->
	 
		<!-- /list header -->
		
		
		<div class="row">
			<div class="col-md-12">
			
				<!-- Card grid view -->
				<div class="cards-container box-view grid-view">
					<div class="row">
					<?php   
					include_once"data/curd.php";
					$obj=new curd();
					$data=$obj->member_request();
					foreach ($data as  $value) {
						$userid=$value['id'];
						$username=$value['username'];
						$password=$value['password'];
						$image=$value['image'];
						$email=$value['email'];
						$name=$value['name'];
						$lastname=$value['lastname'];
						$type=$value['type'];
						$status=$value['status'];
						$state="";
						$color="";
						if ($status==0) {
							$state="تائید ناشده";
						}
						else
						if ($status==1) {
							$state="تائید شده";
						}
						else{
							$state="مسدود شده";
							$color="red";
						}


						echo "
						<div class='col-lg-3 col-sm-6 animatedParent animateOnce z-index-47'>
						
							<!-- Card -->
							<div class='card animated fadeInUp'>
							
								<!-- Card header -->
								<div class='card-header'>
									<div class='card-photo'>
										<img class='img-circle avatar' src='userphoto/$userid.jpg' alt='John Smith' title='John Smith'>
									</div>
									<div class='card-short-description'>
										<h5><span class='user-name'><a href='#/'' id='member_request'>$name $lastname</a></span></h5>
										<p><span class='badge badge-primary' id='member_request' style='background-color:$color;'>$state</span></p>
									</div>
								</div>
								<!-- /card header -->
								
								<!-- Card content -->
								<div class='card-content'>
								    <p id='member_request'>نام:$name</p>
									<p id='member_request'>تخلص:$lastname</p>
									<p id='member_request'>نام کاربری :$username</p>
									<p id='member_request'>رمز عبور:$password</p>
									<p id='member_request'>ایمیل آدرس :$email</p>
									
									<p id='member_request'>درخواست برای بخش : $type </p>
								</div>
								<!-- /card content -->
								
								<!-- Card footer -->
								<div class='card-footer clearfix'>
									<ul class='list-inline'>
										<li><a href='business/confirm.php?status=1 & userid=$userid' id='member_request'><i class='icon-check'></i>تائید کردن</a></li>
										<li><a href='business/confirm.php?status=-1 & userid=$userid' id='member_request'><i class='icon-cancel' ></i>رد کردن</a></li>
									
									</ul>
								</div>
								<!-- /card footer -->
								
							</div>
							<!-- /card -->
							
						</div>






						";


					}




					?>

											
						
					</div>
				
				</div>
				<!-- /card grid view -->
				
			</div>
		</div>	
		
		<!-- Footer -->
		<footer class="animatedParent animateOnce z-index-10"> 
			<div class="footer-main animated fadeInUp slow" id="member_request" style="text-align: center">&copy; تمامی حقوف این سایت متعلق به  <strong>افغان مودل </strong> می باشد  </div>
		</footer>
		<!-- /footer -->
		
	  </div>
	  <!-- /main content -->
	  
  </div>
  <!-- /main container -->
  
</div>
<!-- /page container -->

<!--Load JQuery-->
<script src="js/jquery.min.js"></script>
<!-- Load CSS3 Animate It Plugin JS -->
<script src="js/plugins/css3-animate-it-plugin/css3-animate-it.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/plugins/metismenu/jquery.metisMenu.js"></script>
<!-- Select2-->
<script src="js/plugins/select2/select2.full.min.js"></script>
<script src="js/functions.js"></script>
<script>
	$(document).ready(function () {
		$(".select2").select2();
	});
</script>
</body>

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/detailed-view-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:43:21 GMT -->
</html>
