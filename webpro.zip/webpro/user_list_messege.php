<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:41:18 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Mouldifi - A fully responsive, HTML5 based admin theme">
<meta name="keywords" content="Responsive, HTML5, admin theme, business, professional, Mouldifi, web design, CSS3">
<title>افغان مودل | پیام</title>
<!-- Site favicon -->
<link rel='shortcut icon' type='image/x-icon' href='images/icon2.png' />
<!-- /site favicon -->




<!-- Entypo font stylesheet -->
<link href="fonts/myfont.css" rel="stylesheet">
<!-- /entypo font stylesheet -->

<!-- CSS3 Animate It Plugin Stylesheet -->
<link href="css/plugins/css3-animate-it-plugin/animations.css" rel="stylesheet">
<!-- /css3 animate it plugin stylesheet -->

<!-- Bootstrap stylesheet min version -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!-- /bootstrap stylesheet min version -->

<!-- Mouldifi core stylesheet -->
<link href="css/mouldifi-core.css" rel="stylesheet">
<!-- /mouldifi core stylesheet -->

<link href="css/mouldifi-forms.css" rel="stylesheet">

<!-- Bootstrap RTL stylesheet min version -->
<link href="css/bootstrap-rtl.min.css" rel="stylesheet">
<!-- /bootstrap rtl stylesheet min version -->

<!-- Mouldifi RTL core stylesheet -->
<link href="css/mouldifi-rtl-core.css" rel="stylesheet">
<!-- /mouldifi rtl core stylesheet -->


<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />

<script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
<!--
messege file

-->

<style>


.container {
    border: 2px solid #dedede;
    background-color: #f1f1f1;
    border-radius: 5px;
    padding: 10px;
    margin: 10px 0;
    width: 100%;
}

.darker {
    border-color: #ccc;
    background-color: #ddd;
}

.container::after {
    content: "";
    clear: both;
    display: table;
}

.container img {
    float: left;
    max-width: 60px;
    width: 100%;
    margin-right: 20px;
    border-radius: 50%;
}

.container img.right {
    float: right;
    margin-left: 20px;
    margin-right:0;
}

.time-right {
    float: right;
    color: #aaa;
}

.time-left {
    float: left;
    color: #999;
}
</style>


</head>
<body class="login-page" id="body">
<?php
$id=$_GET['id'];



?>

	<div class="login-pag-inner">
		<div class="animatedParent animateOnce z-index-50">
			<div class="login-container animated growIn slower">
				
				<div class="login-content" style="height :600px; overflow: scroll;">
					
					<div class="animatedParent animateOnce z-index-50">
      <div class="table-responsive indent-row animated fadeInUp">
        <table class="table table-users table-unbordered table-hover table-separate">
          <tbody>
            <tr>
           
              <td class="size-80"><a href="messege.php?id=<?php echo $id; ?> & name=kamal"><img class="avatar img-circle" src="images/john-smith.png" alt="" title=""> </a></td>
              <td><strong>John Smith</strong></td>
              
              <td>Last login yesterday.</td>
              <td class="text-center"><span class="badge badge-bordered">Admin</span></td>
              
            
            </tr>
            <tr>
              
              <td><img class="avatar img-circle" src="images/stella-johnson.png" alt="" title=""></td>
              <td><strong>Stella Johnson</strong></td>
              
              <td>Last login 5 days ago.</td>
              <td class="text-center"><span class="badge badge-bordered">operator</span></td>
             
            </tr>
            
              <td><img class="avatar img-circle" src="images/domnic-brown.png" alt="" title=""></td>
              <td><strong>John K Cooper</strong></td>
              
              <td>Last login 2 mins ago.</td>
              <td class="text-center"><span class="badge badge-bordered">operator</span></td>
              
            </tr>
            <tr>
             
              <td><img class="avatar img-circle" src="images/alex-dolgove.png" alt="" title=""></td>
              <td><strong>Alex Dolgove</strong></td>
              
              <td>Last login 1 year ago.</td>
              <td class="text-center"><span class="badge badge-bordered">operator</span></td>
             
            </tr>

            <tr >
             
              <td><img class="avatar img-circle" src="images/man-3.jpg" alt="" title=""></td>
              <td><strong>John Smith</strong></td>
              
              <td>Last login yesterday.</td>
              <td class="text-center"><span class="badge badge-bordered">customer</span></td>
              
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    
					






				</div>
			</div>
		</div>
	</div>
<!--Load JQuery-->
<script src="js/jquery.min.js"></script>
<!-- Load CSS3 Animate It Plugin JS -->
<script src="js/plugins/css3-animate-it-plugin/css3-animate-it.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:41:18 GMT -->
</html>
