<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/detailed-view-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:43:21 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Mouldifi - A fully responsive, HTML5 based admin theme">
<meta name="keywords" content="Responsive, HTML5, admin theme, business, professional, Mouldifi, web design, CSS3">
<title>Mouldifi | Detailed View</title>
<!-- Site favicon -->
<link rel='shortcut icon' type='image/x-icon' href='images/favicon.ico' />
<!-- /site favicon -->

<!-- Entypo font stylesheet -->
<link href="css/entypo.css" rel="stylesheet">
<link href="fonts/custom.css" rel="stylesheet">
<link href="fonts/myfont.css" rel="stylesheet">
<!-- /entypo font stylesheet -->

<!-- Font awesome stylesheet -->
<link href="css/font-awesome.min.css" rel="stylesheet">
<!-- /font awesome stylesheet -->

<!-- CSS3 Animate It Plugin Stylesheet -->
<link href="css/plugins/css3-animate-it-plugin/animations.css" rel="stylesheet">
<!-- /css3 animate it plugin stylesheet -->

<!-- Bootstrap stylesheet min version -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!-- /bootstrap stylesheet min version -->

<!-- Mouldifi core stylesheet -->
<link href="css/mouldifi-core.css" rel="stylesheet">
<!-- /mouldifi core stylesheet -->

<link href="css/plugins/select2/select2.css" rel="stylesheet">
<link href="css/mouldifi-forms.css" rel="stylesheet">

<!-- Bootstrap RTL stylesheet min version -->
<link href="css/bootstrap-rtl.min.css" rel="stylesheet">
<!-- /bootstrap rtl stylesheet min version -->

<!-- Mouldifi RTL core stylesheet -->
<link href="css/mouldifi-rtl-core.css" rel="stylesheet">
<!-- /mouldifi rtl core stylesheet -->


<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
<![endif]-->
</head>
<body>

<!-- Page container -->
<div class="page-container">

  <!-- Page Sidebar -->
 
  <!-- /page sidebar -->
  
  <!-- Main container -->
  <div class="main-container">
  
	<!-- Main header -->
    <div class="main-header row gray-bg">

	  
      
    </div>
	<!-- /main header -->
	
	<!-- Secondary header -->
	
	<!-- /secondary header -->
	

	<!-- /filter wrapper -->
	
	<!-- Main content -->
    <div class="main-content">
	
		<!-- List header -->
	 
		<!-- /list header -->
		
		
		
				<!-- Card grid view -->
				
					<?php


include_once"data/curd.php";
$obj=new curd();
$userid=$_GET['userid'];
$data=$obj->show_mycourse($userid);
foreach ($data as $value) {
	$id=$value['id'];
	$fullname=$value['fullname'];
	$shortname=$value['shortname'];
	$file=$value['file'];
	$data=$value['date'];
	$userid=$value['userid'];
    $d=$obj->user_info($userid);
    $name="";
    $lastname="";
    $email="";
    foreach ($d as $value2) {
    	$name=$value2['name'];
    	$lastname=$value2['lastname'];
    	$email=$value2['email'];

    }

	echo "
	<div class='cards-container box-view'>
				
					<div class='animatedParent animateOnce z-index-50'>
						<!-- Card -->
						<div class='card animated fadeInUp' id='post$id'>
						
							<!-- Card header -->
							<div class='card-header'>
							
								<!-- Card photo -->
								<div class='card-photo'>
									<img class='img-circle avatar' src='userphoto/$userid.jpg' alt='$lastname' title='John Henderson'>
								</div>
								<!-- /card photo -->
								
								<!-- Card short description -->
								<div class='card-short-description' >
									<h5><span class='user-name'><a href='user_info.php?userid=$userid' id='post_header'>$name  $lastname</a></span></h5>
									<p><a href='mailto:$email' id='post_header'>$email</a></p>
								</div>
								
								<!-- /card short description -->
								
							</div>
							<!-- /card header -->
							
							<!-- Card content -->
							<div class='card-content'>
								<div >
									<h3 id='post_title'>$shortname</h3>
								</div>
								<p id='post_desc'>$fullname</p>
								<ul class='list-inline list-action'>
									<li><a href='course_info.php?cid=$id & username=$name' id='post_desc'>توضیحات بیشتر</a></li>
									
									<li><a href='messege.php?id=$userid & name=$name' id='post_desc'>ارسال پیام</a></li>
								</ul>
							</div>
							<!-- /card content -->
							
						</div>
						<!-- /card -->
					</div>
					
					
				</div>

	";



}





					?>

											
				
				<!-- /card grid view -->
		
		<!-- Footer -->
			
		<!-- /footer -->
		
	  </div>
	  <!-- /main content -->
	  
  </div>
  <!-- /main container -->
  
</div>
<!-- /page container -->

<!--Load JQuery-->
<script src="js/jquery.min.js"></script>
<!-- Load CSS3 Animate It Plugin JS -->
<script src="js/plugins/css3-animate-it-plugin/css3-animate-it.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/plugins/metismenu/jquery.metisMenu.js"></script>
<!-- Select2-->
<script src="js/plugins/select2/select2.full.min.js"></script>
<script src="js/functions.js"></script>
<script>
	$(document).ready(function () {
		$(".select2").select2();
	});
</script>
</body>

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/detailed-view-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:43:21 GMT -->
</html>
