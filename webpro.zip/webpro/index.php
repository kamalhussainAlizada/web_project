<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:41:18 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="افغات مودل">
<meta name="keywords" content="مودل">
<title>Afghan Moodel | Login</title>
<!-- Site favicon -->
<link rel='shortcut icon' type='image/x-icon' href='images/icon2.png' />
<!-- /site favicon -->

<!-- Entypo font stylesheet -->
<link href="css/entypo.css" rel="stylesheet">
<!-- /entypo font stylesheet -->

<!-- Entypo font stylesheet -->
<link href="fonts/myfont.css" rel="stylesheet">
<!-- /entypo font stylesheet -->

<!-- Font awesome stylesheet -->
<link href="css/font-awesome.min.css" rel="stylesheet">
<!-- /font awesome stylesheet -->

<!-- CSS3 Animate It Plugin Stylesheet -->
<link href="css/plugins/css3-animate-it-plugin/animations.css" rel="stylesheet">
<!-- /css3 animate it plugin stylesheet -->

<!-- Bootstrap stylesheet min version -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!-- /bootstrap stylesheet min version -->

<!-- Mouldifi core stylesheet -->
<link href="css/mouldifi-core.css" rel="stylesheet">
<!-- /mouldifi core stylesheet -->

<link href="css/mouldifi-forms.css" rel="stylesheet">

<!-- Bootstrap RTL stylesheet min version -->
<link href="css/bootstrap-rtl.min.css" rel="stylesheet">
<!-- /bootstrap rtl stylesheet min version -->

<!-- Mouldifi RTL core stylesheet -->
<link href="css/mouldifi-rtl-core.css" rel="stylesheet">
<!-- /mouldifi rtl core stylesheet -->

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
<![endif]-->


</head>
<body class="login-page" id="body">
	<div class="login-pag-inner">
		<div class="animatedParent animateOnce z-index-50">
			<div class="login-container animated growIn slower">
				<div class="login-branding">
					<a href="index-2.html"><img src="images/persion_logo.png" alt="Mouldifi" title="Mouldifi"></a>
				</div>
				<div class="login-content">
					<h2 id='title'><strong>خوش آمدید</strong>, لطفا نام و رمز کاربری خود را واردی کنید</h2>
					<form method="post" action="business/check_user_file.php">                        
						<div class="form-group">
							<input type="text" placeholder="نام کاربری" class="form-control" style="font-size: 22px" name="username" required="required">
						</div>                        
						<div class="form-group">
							<input type="password" placeholder="رمز ورود" class="form-control" style="font-size: 22px" name="password" required="required">
						</div>
						<div class="form-group">
							 <div class="checkbox checkbox-replace">
								<input type="checkbox" id="remember2" name="remember" value="active">
								<label for="remembe2r" style="font-size: 19px">مرا در حالت ورود نگهدارید</label>
							  </div>
						 </div>
						<div class="form-group">
							<button class="btn btn-primary btn-block" style="font-size: 28px;">ورود</button>
						</div>
						<p class="text-center"><a href="forgot-password.html" style="font-size:21px;">ورود به عنوان کاربر مهمان</a></p>
						<p class="text-center"><a href="register.php" style="font-size:21px;">ایجاد حساب کاربری جدید</a></p>

						                        
					</form>
				</div>
			</div>
		</div>
	</div>
<!--Load JQuery-->
<script src="js/jquery.min.js"></script>
<!-- Load CSS3 Animate It Plugin JS -->
<script src="js/plugins/css3-animate-it-plugin/css3-animate-it.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:41:18 GMT -->
</html>
