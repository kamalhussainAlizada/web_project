<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:41:18 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Mouldifi - A fully responsive, HTML5 based admin theme">
<meta name="keywords" content="Responsive, HTML5, admin theme, business, professional, Mouldifi, web design, CSS3">
<title>افغان مودل | اضافه نمودن دوره ای آموزشی</title>
<!-- Site favicon -->
<link rel='shortcut icon' type='image/x-icon' href='images/icon2.png' />
<!-- /site favicon -->




<!-- Entypo font stylesheet -->
<link href="fonts/myfont.css" rel="stylesheet">
<!-- /entypo font stylesheet -->

<!-- CSS3 Animate It Plugin Stylesheet -->
<link href="css/plugins/css3-animate-it-plugin/animations.css" rel="stylesheet">
<!-- /css3 animate it plugin stylesheet -->

<!-- Bootstrap stylesheet min version -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!-- /bootstrap stylesheet min version -->

<!-- Mouldifi core stylesheet -->
<link href="css/mouldifi-core.css" rel="stylesheet">
<!-- /mouldifi core stylesheet -->

<link href="css/mouldifi-forms.css" rel="stylesheet">

<!-- Bootstrap RTL stylesheet min version -->
<link href="css/bootstrap-rtl.min.css" rel="stylesheet">
<!-- /bootstrap rtl stylesheet min version -->

<!-- Mouldifi RTL core stylesheet -->
<link href="css/mouldifi-rtl-core.css" rel="stylesheet">
<!-- /mouldifi rtl core stylesheet -->



</head>
<body class="login-page" id="body">
	<?php
    $userid=$_GET['userid'];



	?>
	<div class="login-pag-inner">
		<div class="animatedParent animateOnce z-index-50">
			<div class="login-container animated growIn slower">
				<div class="login-branding">
					<a href="#"><img src="images/persion_logo.png" alt="Mouldifi" title="Mouldifi"></a>
				</div>
				<div class="login-content">
					<h2 id='title' style="font-weight: bold;">دوره آموزشی جدید</h2>
					<form method="post" action="business/create_course.php?userid=<?php echo $userid; ?>" method="post" enctype="multipart/form-data" >                        
						<div class="form-group">
							<input type="text" placeholder="نام دوره" class="form-control" style="font-size: 21px;" name="shortname" required="required">
						</div>
						<div class="form-group">
							
							<textarea  rows="2" cols="23" style="font-size: 21px;" name="fullname" required="required" placeholder="توضیحات"></textarea>
						</div>
						
						<div class="form-group" >
							<input type="file" placeholder="فایل" name="file"  required="required">
						</div>
						<div class="form-group form-action">
							<button class="btn btn-primary btn-block" style="font-size: 22px; font-weight: bold;" name="submit">ایجاد دوره</button>
						</div>
						
				</div>
			</div>
		</div>
	</div>
<!--Load JQuery-->
<script src="js/jquery.min.js"></script>
<!-- Load CSS3 Animate It Plugin JS -->
<script src="js/plugins/css3-animate-it-plugin/css3-animate-it.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:41:18 GMT -->
</html>
