<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/strip-view.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:43:21 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Mouldifi - A fully responsive, HTML5 based admin theme">
<meta name="keywords" content="Responsive, HTML5, admin theme, business, professional, Mouldifi, web design, CSS3">
<title>Mouldifi | Strip View</title>
<!-- Site favicon -->
<link rel='shortcut icon' type='image/x-icon' href='images/favicon.ico' />
<!-- /site favicon -->

<!-- Entypo font stylesheet -->
<link href="css/entypo.css" rel="stylesheet">
<!-- /entypo font stylesheet -->

<!-- Font awesome stylesheet -->
<link href="css/font-awesome.min.css" rel="stylesheet">
<link href="fonts/custom.css" rel="stylesheet">
<!-- /font awesome stylesheet -->

<!-- CSS3 Animate It Plugin Stylesheet -->
<link href="css/plugins/css3-animate-it-plugin/animations.css" rel="stylesheet">
<!-- /css3 animate it plugin stylesheet -->

<!-- Bootstrap stylesheet min version -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!-- /bootstrap stylesheet min version -->

<!-- Mouldifi core stylesheet -->
<link href="css/mouldifi-core.css" rel="stylesheet">
<!-- /mouldifi core stylesheet -->

<link href="css/plugins/select2/select2.css" rel="stylesheet">

<link href="css/mouldifi-forms.css" rel="stylesheet">

<!-- Bootstrap RTL stylesheet min version -->
<link href="css/bootstrap-rtl.min.css" rel="stylesheet">
<!-- /bootstrap rtl stylesheet min version -->

<!-- Mouldifi RTL core stylesheet -->
<link href="css/mouldifi-rtl-core.css" rel="stylesheet">
<!-- /mouldifi rtl core stylesheet -->

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
<![endif]-->
<script type="text/javascript">
@font-face {
  font-family:'a';
  src:url('adobearabic-aegular.otf');
}
</script>

</head>
<body>

<!-- Page container -->
<div class="page-container">

  <!-- Page Sidebar -->

  <!-- /page sidebar -->
  
  <!-- Main container -->
  <div class="main-container gray-bg">
  
	
	<!-- /main header -->
	
	<!-- Secondary header -->
	
	<!-- /secondary header -->
	
	<!-- Filter wrapper -->
	
	<!-- /filter wrapper -->
	
	<!-- Main content -->
	<div class="main-content">

		<?php  
		$userid=$_GET['userid'];

		  ?>
		
		<div class="animatedParent animateOnce z-index-50">
			<div class="table-responsive indent-row animated fadeInUp">
				<table class="table table-users table-unbordered table-hover table-separate">
					<tbody>
						<?php
						include_once"data/curd.php";
						$ob=new curd();
						$result=$ob->list_user_for_messege($userid);

						foreach ($result as  $value) {

							$name=$value['name'];
							$id=$value['id'];
							$lastname=$value['lastname'];
							$email=$value['email'];
							$status=$value['status'];
							$state="";
							$icon="";
							if ($status==0) {
								$state="تائید ناشده";
								$icon="icon-cancel icon-larger red-color";
							}else 
							if ($status==1) {
								$state="فعال";
								$icon="icon-check icon-larger green-color";
							}
							else{
								$state="غیر فعال";
								$icon="icon-cancel icon-larger red-color";
							}

							$type=$value['type'];
							
 								if ($userid!=$id) {
								
							
                             
							echo "
							<tr >
							
							<td class='size-80'><a href='messege.php?id=$userid &name=$name & pid=$id'><img class='avatar img-circle' src='userphoto/$id.jpg' alt='' title=''></a></td>
							<td class='list_user'><strong>$name $lastname</strong></td>
							<td class='list_user'>$email</td>
							<td class='text-center' ><span class='badge badge-bordered' id='list_user'>$type</span></td>
							<td class='text-center' class='list_user'><i class='$icon'></i></td>
						    <td class='list_user'>$state</td>
						</tr>






							";
							
								}
						}


						?>
						
						
					</tbody>
				</table>
			</div>
		</div>
		
		<!-- Footer -->
			
		<!-- /footer -->
		
	  </div>
	  <!-- /main content -->
	  
  </div>
  <!-- /main container -->
  
</div>
<!-- /page container -->

<!--Load JQuery-->
<script src="js/jquery.min.js"></script>
<!-- Load CSS3 Animate It Plugin JS -->
<script src="js/plugins/css3-animate-it-plugin/css3-animate-it.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/plugins/metismenu/jquery.metisMenu.js"></script>
<!-- Select2-->
<script src="js/plugins/select2/select2.full.min.js"></script>
<script src="js/functions.js"></script>
<script>
	$(document).ready(function () {
		$(".select2").select2();
	});
</script>
</body>

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/strip-view.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:43:21 GMT -->
</html>
