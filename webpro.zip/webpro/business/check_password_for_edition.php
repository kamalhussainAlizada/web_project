<?php
$pass=$_GET['pass'];
$mainpass=$_GET['mainpass'];
$mainusername=$_GET['mainusername'];
include_once"../data/curd.php";
$obj=new curd();
$obj->check_password_edite($pass,$mainpass,$mainusername);






?>