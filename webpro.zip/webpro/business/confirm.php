<?php
include_once"../data/curd.php";
$status=$_GET['status'];
$userid=$_GET['userid'];
$obj=new curd();
$obj->confirm_users($userid,$status);




?>