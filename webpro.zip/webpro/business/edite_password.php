<?php
$userid=$_GET['userid'];
$old_password=$_POST['oldPassword'];
$new_password=$_POST['newPassword'];
include_once"../data/curd.php";
$obj=new curd();
$a=$obj->edite_password($userid,$old_password,$new_password);





?>