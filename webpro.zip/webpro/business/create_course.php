<?php
$userid=$_GET['userid'];
$shortname=$_POST['shortname'];
$fullname=$_POST['fullname'];
$file_name=$_FILES['file']['tmp_name'];
$file_type=$_FILES['file']['type'];

include_once"../data/curd.php";
$obj=new curd();
$obj->create_cours($userid,$shortname,$fullname,$file_name,$file_type);


?>