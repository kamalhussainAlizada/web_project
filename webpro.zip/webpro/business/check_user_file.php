<?php
$username=$_POST['username'];
$password=$_POST['password'];
$remember="";
if(isset($_POST['remember'])){
	$remember="anabile";
}
else{
	$remember="disable";
}
$data = array('username' =>$username ,'password'=>$password,'remember'=>$remember );

include_once"../data/curd.php";
$obj=new curd();
$obj->check_user($data);





?>