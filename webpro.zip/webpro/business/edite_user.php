<?php
$password=$_GET['pass'];
$userid=$_GET['userid'];
$name=$_POST['name'];
$lastname=$_POST['lastname'];
$email=$_POST['email'];
$photo=$_FILES['photo']['tmp_name'];
$username=$_POST['username'];
include_once"../data/curd.php";
$obj=new curd();

$obj->edite_user($password,$userid,$name,$lastname,$email,$photo,$username);




?>