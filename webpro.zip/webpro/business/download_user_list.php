<?php
$status=$_GET['status'];
include_once"../data/curd.php";
$obj=new curd();
if ($status=='همه') {
	$obj->download_all_user_list();
}
else{
	$obj->download_user_list($status);

}









?>