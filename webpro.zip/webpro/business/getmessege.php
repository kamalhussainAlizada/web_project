<?php
$sid=$_GET['sid'];
$pid=$_GET['pid'];
$name=$_GET['name'];
$messege=$_POST['messege'];
include_once"../data/curd.php";
$ob=new curd();
$ob->messege($messege,$name,$sid,$pid);




?>