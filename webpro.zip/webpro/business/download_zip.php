<?php
$filename=$_GET['filename'];
$fileid=$_GET['fileid'];
include_once"../data/curd.php";
$obj=new curd();
$obj->Zip_download_file($filename,$fileid);



?>