<?php
include_once"../data/curd.php";
$name=$_POST["name"];
$lastname=$_POST["lastname"];
$email=$_POST["email"];
$username=$_POST["username"];
$password=$_POST["password"];
$type=$_POST["kind"];
$image=$_FILES['image']['tmp_name'];
//$image=$_FILES['image']['tmp_name'];
$data=array('name' =>$name ,'lastname' =>$lastname,'email' =>$email,'username' =>$username,'password' =>$password,'type' =>$type,'image' =>$image );

$namePattern = "/^[A-Za-z]{3,}$/";
$emailPattern="/^[A-Za-z]+\w{1,}\.*@(\w+\.)+[A-Za-z]+$/";
if (preg_match($emailPattern,$email) & preg_match($namePattern,$name) & preg_match($namePattern,$lastname)) {
	$obj=new curd();
    $obj->create_user($data);

}
else{
	header("location:../register.php");
}
 









?>