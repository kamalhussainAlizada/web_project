<?php
$postid=$_GET['postid'];
$filename=$_GET['filename'];
$userid=$_GET['userid']
include_once"../data/curd.php";
$obj=new curd();
$obj->delete_post($postid,$filename,$userid);





?>