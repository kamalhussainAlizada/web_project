<?php
include_once"../data/curd.php";
$status=$_GET['status'];
$userid=$_GET['userid'];
$obj=new curd();
$obj->closed_users($userid,$status);




?>