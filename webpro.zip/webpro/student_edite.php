﻿<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:41:18 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Mouldifi - A fully responsive, HTML5 based admin theme">
<meta name="keywords" content="Responsive, HTML5, admin theme, business, professional, Mouldifi, web design, CSS3">
<title>افغان مودل | ویرایش حساب</title>
<!-- Site favicon -->
<link rel='shortcut icon' type='image/x-icon' href='images/icon2.png' />
<!-- /site favicon -->




<!-- Entypo font stylesheet -->
<link href="fonts/myfont.css" rel="stylesheet">
<!-- /entypo font stylesheet -->

<!-- CSS3 Animate It Plugin Stylesheet -->
<link href="css/plugins/css3-animate-it-plugin/animations.css" rel="stylesheet">
<!-- /css3 animate it plugin stylesheet -->

<!-- Bootstrap stylesheet min version -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!-- /bootstrap stylesheet min version -->

<!-- Mouldifi core stylesheet -->
<link href="css/mouldifi-core.css" rel="stylesheet">
<!-- /mouldifi core stylesheet -->

<link href="css/mouldifi-forms.css" rel="stylesheet">

<!-- Bootstrap RTL stylesheet min version -->
<link href="css/bootstrap-rtl.min.css" rel="stylesheet">
<!-- /bootstrap rtl stylesheet min version -->

<!-- Mouldifi RTL core stylesheet -->
<link href="css/mouldifi-rtl-core.css" rel="stylesheet">
<!-- /mouldifi rtl core stylesheet -->
<script type="text/javascript">
function checkpass(pass){
var mainpass=document.getElementById("main").value;
var mainusername=document.getElementById("usernamemain").value;
var request=new XMLHttpRequest();
request.onreadystatechange=function(){
	if(request.readyState==4){
      var resp=request.responseText;
      var res2=resp+"";
      if(res2==1){
      	document.getElementById("showResultForEdite").innerHTML="<span style='color:green'>رمز کاربری درست است</span>";
      }
      else{
        document.getElementById("showResultForEdite").innerHTML="<span style='color:red'>رمز کاربری خود را درست وارد کنید!!</span>";	
      }

		


	}

}
request.open("GET","business/check_password_for_edition.php?pass="+pass+" & mainpass="+mainpass+" & mainusername="+mainusername);
request.send(null);




}
	
	
    

</script>


</head>
<body class="login-page" id="body">
	<?php

  	$userid2=$_GET['userid'];
  	$userid=$userid2+0;
	?>
	<div class="login-pag-inner">
		<div class="animatedParent animateOnce z-index-50">
			<div class="login-container animated growIn slower">
				
				<div class="login-content">
                     <div class="card-photo">
					    <center><img class="img-circle avatar" src="userphoto/<?php  echo $userid; ?>.jpg" alt="John Henderson" title="John Henderson">
					    </center>
					 </div>

					<h2 id='title' style="font-weight: bold; text-align: center">ویرایش حساب کاربری</h2>
                    <?php  
                    include_once"data/curd.php";
                    $obj=new curd();
                    $result=$obj->user_info($userid);
                    $password="";
                    $name="";
                    $lastname="";
                    $username="";
                    $email="";
                    foreach ($result as  $value) {
                    	$password=$value['password'];
                    	$name=$value['name'];
                    	$lastname=$value['lastname'];
                    	$username=$value['username'];
                    	$email=$value['email'];

                    }


                    ?>

					<form method="post" action="business/edite_user.php?pass=<?php echo $password; ?>& userid=<?php echo $userid; ?>" enctype="multipart/form-data" >
						<div id="showResultForEdite" style="color: blue; font-size: 20px;">لطفا رمز عبور قبلی خود را وارد کنید!</div>
					 <div class="form-group">
					 	<input type="hidden" id="main" value="<?php echo $password; ?>">
					 	<input type="hidden" id="usernamemain" value="<?php echo $username; ?>">
				<input type="password" id="oldpass"  placeholder="رمز عبور قدیمی" class="form-control" style="font-size: 21px;"  name="password" value="testing" onchange ="checkpass(this.value);" required="required">
						</div>                 
						<div class="form-group">
							<input type="text" placeholder="اسم" class="form-control" style="font-size: 21px;"   name="name" value="<?php echo $name; ?>" required="required" >
						</div>
						<div class="form-group">
							<input type="text" placeholder="تخلص" class="form-control" style="font-size: 21px;"  name="lastname" value="<?php echo $lastname; ?>" required="required">
						</div>

						<div class="form-group">
							<input type="text" placeholder="ایمیل آدرس" class="form-control" style="font-size: 21px;"  name="email" value="<?php echo $email; ?>" required="required">
						</div>
						<div class="form-group">
							<input type="text" placeholder="نام کاربری" class="form-control" style="font-size: 21px;"  name="username" value="<?php echo $username; ?>" required="required">
						</div>                     
						
						
						<div class="form-group">
							<input type="file" placeholder="عکس" name="photo">
						</div>
						<div class="form-group form-action">
							<button class="btn btn-primary btn-block" style="font-size: 22px; font-weight: bold;">تائید ویرایش</button>
						</div>
						<p class="text-center" style="font-size: 21px;"><a href="#">لغو ویرایش</a></p>                        
					</form>
				</div>
			</div>
		</div>
	</div>
<!--Load JQuery-->
<script src="js/jquery.min.js"></script>
<!-- Load CSS3 Animate It Plugin JS -->
<script src="js/plugins/css3-animate-it-plugin/css3-animate-it.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>

<!-- Mirrored from www.g-axon.com/mouldifi-5.0/rtl/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Dec 2017 07:41:18 GMT -->
</html>
