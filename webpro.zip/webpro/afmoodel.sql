-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 10, 2018 at 04:12 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `afmoodel`
--

-- --------------------------------------------------------

--
-- Table structure for table `answare`
--

CREATE TABLE IF NOT EXISTS `answare` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `second` varchar(70) COLLATE utf8_persian_ci NOT NULL,
  `third` varchar(70) COLLATE utf8_persian_ci NOT NULL,
  `fourth` varchar(70) COLLATE utf8_persian_ci NOT NULL,
  `correct` varchar(70) COLLATE utf8_persian_ci NOT NULL,
  `question id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE IF NOT EXISTS `chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `messege` varchar(400) COLLATE utf8_persian_ci NOT NULL,
  `date` varchar(30) COLLATE utf8_persian_ci NOT NULL,
  `senderrid` int(11) NOT NULL,
  `reciever` int(11) NOT NULL,
  `courseid` int(11) NOT NULL DEFAULT '0',
  `type` varchar(30) COLLATE utf8_persian_ci NOT NULL DEFAULT 'course',
  PRIMARY KEY (`id`),
  KEY `userid` (`senderrid`),
  KEY `reciever` (`reciever`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=86 ;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`id`, `messege`, `date`, `senderrid`, `reciever`, `courseid`, `type`) VALUES
(50, 'سلام', '2018/Jul/Mon', 38, 34, 0, 'course'),
(51, 'خوب استین؟', '2018/Jul/Mon', 38, 34, 0, 'course'),
(52, 'میشه با من تماس بگیرید؟', '2018/Jul/Mon', 38, 34, 0, 'course'),
(53, 'سلام', '2018/Jul/Mon', 38, 32, 0, 'course'),
(54, 'شماره شما چند است محترم؟', '2018/Jul/Mon', 38, 32, 0, 'course'),
(55, 'سلام مصطفی جان', '2018/Jul/Mon', 38, 33, 0, 'course'),
(56, 'سلام ', '2018/Jul/Mon', 32, 38, 0, 'course'),
(57, 'خوبم شما چطورید؟', '2018/Jul/Mon', 32, 38, 0, 'course'),
(58, 'سلام خام فاطمه', '2018/Jul/Mon', 32, 35, 0, 'course'),
(59, 'سلام', '2018/Jul/Mon', 32, 36, 0, 'course'),
(60, 'کجایی استاد جان؟', '2018/Jul/Mon', 32, 34, 0, 'course'),
(61, 'salam', '2018/Jul/Mon', 33, 36, 0, 'course'),
(62, 'khobin', '2018/Jul/Mon', 33, 36, 0, 'course'),
(63, 'HI', '2018/Jul/Mon', 33, 32, 0, 'course'),
(64, 'سلام اقای علیزاده', '2018/Jul/Mon', 32, 35, 0, 'course'),
(65, 'سلام اقای یوسفی', '2018/Jul/Mon', 35, 34, 0, 'course'),
(66, 'سلام اقای حسینی', '2018/Jul/Mon', 35, 37, 0, 'course'),
(67, 'سلام ادمین صاحب', '2018/Jul/Mon', 36, 38, 0, 'course'),
(68, 'ایمیل شما درست کار نمی کند!', '2018/Jul/Mon', 36, 38, 0, 'course'),
(72, 'salam', '2018/Jul/Mon', 32, 38, 0, 'course'),
(73, 'salam', '2018/Jul/Mon', 38, 36, 0, 'course'),
(74, 'به این ایمیل به تماس شوید', '2018/Jul/Mon', 38, 36, 0, 'course'),
(75, 'Kamal.hussain4545@gmail.com', '2018/Jul/Mon', 38, 36, 0, 'course'),
(76, 'یا به این شماره   0797932126', '2018/Jul/Mon', 38, 36, 0, 'course'),
(77, 'سلام اقای حسینی', '2018/Jul/Mon', 36, 37, 0, 'course'),
(78, 'salam', '2018/Jul/Mon', 38, 34, 0, 'course'),
(79, 'سلام اقای محمدی', '2018/Jul/Mon', 33, 36, 0, 'course'),
(82, 'salam', '2018/Jul/Mon', 32, 35, 0, 'course'),
(83, 'khobi', '2018/Jul/Mon', 32, 35, 0, 'course'),
(84, 'salam kamal', '2018/Jul/Mon', 32, 38, 0, 'course'),
(85, 'kojaee', '2018/Jul/Mon', 35, 32, 0, 'course');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE IF NOT EXISTS `course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `shortname` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `date` varchar(30) COLLATE utf8_persian_ci NOT NULL,
  `file` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `fullname`, `shortname`, `date`, `file`, `userid`) VALUES
(9, 'این کتاب به زبان فارسی می باشد . شما (شاگردان صنف اول) می توانید منحیث کتاب منبع استفاده کنید. همچنان این کتاب شامل امتحانات نیز می باشد', 'آموزش جاوا', '2018/Jul/Mon', '1.pdf', 32),
(10, 'این کتاب شامل مرحله های ابتدایی و پیشرفته می باشد. و برای شاگران صنف سوم می باشد', 'اموزش PHP', '2018/Jul/Mon', '10.pdf', 33),
(11, 'این کتاب شامل مرحله های ابتدایی و پیشرفته می باشد. و برای شاگران صنف چهارم نتورک می باشد', 'python', '2018/Jul/Mon', '11.msword', 33),
(12, 'شما می توانید از این کتاب منحیث منبع برای امتحان استفاده کیند', 'سی پلاس پلاس', '2018/Jul/Mon', '12.pdf', 34);

-- --------------------------------------------------------

--
-- Table structure for table `exame`
--

CREATE TABLE IF NOT EXISTS `exame` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(40) COLLATE utf8_persian_ci NOT NULL,
  `time` varchar(30) COLLATE utf8_persian_ci NOT NULL,
  `userid` int(11) NOT NULL,
  `courseid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `courseid` (`courseid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `mention`
--

CREATE TABLE IF NOT EXISTS `mention` (
  `examid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  KEY `examid` (`examid`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permission`
--

CREATE TABLE IF NOT EXISTS `permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `questionbank`
--

CREATE TABLE IF NOT EXISTS `questionbank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `exameid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `exameid` (`exameid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(40) COLLATE utf8_persian_ci NOT NULL,
  `password` varchar(40) COLLATE utf8_persian_ci NOT NULL,
  `image` varchar(40) COLLATE utf8_persian_ci NOT NULL,
  `email` varchar(40) COLLATE utf8_persian_ci NOT NULL,
  `name` varchar(30) COLLATE utf8_persian_ci NOT NULL,
  `lastname` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `type` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=39 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `image`, `email`, `name`, `lastname`, `type`, `status`) VALUES
(32, 'amir', '0987', '32', 'amir22@gmial.com', 'Amirali', 'Alizada', 'استاد', 1),
(33, 'mustafa', '6789', '33', 'Mustafa@yahoo.com', 'Mustafa', 'Muhammady', 'استاد', 1),
(34, 'khalil', '1234', '34', 'KhalilAhamd786@gmail.com', 'KhalilAhmad', 'Yosufi', 'استاد', 1),
(35, 'fatema', '8764', '35', 'Fatemacs@gamil.com', 'Fatema', 'Mohamady', 'شاگرد', 1),
(36, 'nargis33', 'nargis', '36', 'Nargisnabizada99@gmail.com', 'Nargis', 'Nabizada', 'شاگرد', 1),
(37, 'reza1378', '1376', '37', 'RezaJoya@gamil.com', 'Reza', 'Hussaini', 'شاگرد', -1),
(38, 'kamalhussain', '12345', '38', 'kamalhussainalizada@gamil.com', 'Kamal', 'Alizada', 'مدیر', 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chat`
--
ALTER TABLE `chat`
  ADD CONSTRAINT `chat_ibfk_1` FOREIGN KEY (`senderrid`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `chat_ibfk_2` FOREIGN KEY (`reciever`) REFERENCES `users` (`id`);

--
-- Constraints for table `course`
--
ALTER TABLE `course`
  ADD CONSTRAINT `course_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `exame`
--
ALTER TABLE `exame`
  ADD CONSTRAINT `exame_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `exame_ibfk_2` FOREIGN KEY (`courseid`) REFERENCES `course` (`id`);

--
-- Constraints for table `mention`
--
ALTER TABLE `mention`
  ADD CONSTRAINT `mention_ibfk_1` FOREIGN KEY (`examid`) REFERENCES `exame` (`id`),
  ADD CONSTRAINT `mention_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `permission`
--
ALTER TABLE `permission`
  ADD CONSTRAINT `permission_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `questionbank`
--
ALTER TABLE `questionbank`
  ADD CONSTRAINT `questionbank_ibfk_1` FOREIGN KEY (`exameid`) REFERENCES `exame` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
